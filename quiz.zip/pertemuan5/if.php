<?php
$nilai = 80;
if ($nilai >= 60) {
	echo "Nilai Anda $nilai, Anda LULUS";
}

?>