<!DOCTYPE html>
<html>
<body>

<?php
ECHO "Hello Boy!<br>";
echo "Hello Girl!<br>";
EcHo "Hello Gay!<br>";
?>

</body>
</html>