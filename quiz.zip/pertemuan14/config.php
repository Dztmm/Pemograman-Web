<?php

$databaseHost = 'localhost';
$databaseName = 'data_barang_db';
$databaseUsername = 'root';
$databasePassword = 'Dztmsql2#';

$mysqli = new mysqli($databaseHost, $databaseUsername, $databasePassword, $databaseName);

?>