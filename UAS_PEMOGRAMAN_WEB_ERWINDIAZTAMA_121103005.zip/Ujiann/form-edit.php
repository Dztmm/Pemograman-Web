<?php
include("config.php");

// Mengambil ID siswa dari parameter URL
$id = $_GET['id'];

// Query untuk mendapatkan data siswa berdasarkan ID
$sql = "SELECT * FROM calon_siswa WHERE id = $id";
$query = mysqli_query($db, $sql);
$siswa = mysqli_fetch_assoc($query);

// Memeriksa apakah data siswa ditemukan
if (!$siswa) {
    echo "Data siswa tidak ditemukan.";
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Data Siswa | SMA Negeri 29 Jakarta</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <header>
        <h3 class="text-center">Edit Data Siswa</h3>
    </header>

    <div class="container mt-4">
        <form action="proses-edit.php" method="POST">
            <input type="hidden" name="id" value="<?php echo $siswa['id']; ?>">
            <div class="form-group">
                <label for="nama">Nama:</label>
                <input type="text" class="form-control" id="nama" name="nama" value="<?php echo $siswa['nama']; ?>">
            </div>
            <div class="form-group">
                <label for="alamat">Alamat:</label>
                <textarea class="form-control" id="alamat" name="alamat"><?php echo $siswa['alamat']; ?></textarea>
            </div>
            <div class="form-group">
                <label for="jenis_kelamin">Jenis Kelamin:</label>
                <select class="form-control" id="jenis_kelamin" name="jenis_kelamin">
                    <option value="Laki-laki" <?php if ($siswa['jenis_kelamin'] == 'Laki-laki') echo 'selected'; ?>>Laki-laki</option>
                    <option value="Perempuan" <?php if ($siswa['jenis_kelamin'] == 'Perempuan') echo 'selected'; ?>>Perempuan</option>
                </select>
            </div>
            <div class="form-group">
                <label for="agama">Agama:</label>
                <input type="text" class="form-control" id="agama" name="agama" value="<?php echo $siswa['agama']; ?>">
            </div>
            <div class="form-group">
                <label for="sekolah_asal">Sekolah Asal:</label>
                <input type="text" class="form-control" id="sekolah_asal" name="sekolah_asal" value="<?php echo $siswa['sekolah_asal']; ?>">
            </div>
            <button type="submit" class="btn btn-primary">Simpan</button>
            <a href="list-siswa.php" class="btn btn-secondary">Kembali</a>
        </form>
    </div>

    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
