<?php
session_start();

// Periksa apakah metode permintaan adalah POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Periksa apakah username dan password sudah diisi
    if (isset($_POST["username"]) && isset($_POST["password"])) {
        // Periksa apakah username dan password yang dimasukkan benar
        $username = $_POST["username"];
        $password = $_POST["password"];

        // Lakukan validasi login sesuai dengan kebutuhan aplikasi Anda
        if ($username === "admin" && $password === "admin123") {
            // Jika login berhasil, simpan informasi pengguna ke sesi
            $_SESSION["username"] = $username;

            // Alihkan pengguna ke halaman utama
            header("Location: index.php");
            exit();
        } else {
            // Jika login gagal, tampilkan pesan error
            $error = "Username atau password salah.";
        }
    } else {
        // Jika username atau password tidak diisi, tampilkan pesan error
        $error = "Mohon masukkan username dan password.";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Halaman Login</title>
    <!-- Tambahkan link CSS Bootstrap -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
</head>
<body>
    <div class="container">
        <h1 class="mt-4">Halaman Login</h1>

        <?php
        // Tampilkan pesan error jika ada
        if (isset($error)) {
            echo '<p class="text-danger">' . $error . '</p>';
        }
        ?>

        <form method="POST" action="<?php echo $_SERVER["PHP_SELF"]; ?>">
            <div class="form-group">
                <label for="username">Username:</label>
                <input type="text" id="username" name="username" class="form-control" required>
            </div>

            <div class="form-group">
                <label for="password">Password:</label>
                <input type="password" id="password" name="password" class="form-control" required>
            </div>

            <button type="submit" class="btn btn-primary">Login</button>
        </form>
    </div>

    <!-- Tambahkan script Bootstrap -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
</body>
</html>
