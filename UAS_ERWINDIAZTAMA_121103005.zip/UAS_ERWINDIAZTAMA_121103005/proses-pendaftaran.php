<?php
include("config.php");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama = $_POST['nama'];
    $alamat = $_POST['alamat'];
    $jenis_kelamin = $_POST['jenis_kelamin'];
    $agama = $_POST['agama'];
    $sekolah_asal = $_POST['sekolah_asal'];

    // Query SQL untuk memasukkan data pendaftaran ke dalam tabel calon_siswa
    $sql = "INSERT INTO calon_siswa (nama, alamat, jenis_kelamin, agama, sekolah_asal) VALUES ('$nama', '$alamat', '$jenis_kelamin', '$agama', '$sekolah_asal')";
    $result = mysqli_query($db, $sql);

    if ($result) {
        // Jika data berhasil ditambahkan, redirect ke halaman list-siswa.php
        header("Location: list-siswa.php");
        exit();
    } else {
        // Jika terjadi error saat memasukkan data, tampilkan pesan error
        echo "Error: " . mysqli_error($db);
    }
}

mysqli_close($db);
?>
