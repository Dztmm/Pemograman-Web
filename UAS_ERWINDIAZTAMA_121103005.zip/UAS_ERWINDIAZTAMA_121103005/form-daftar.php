<!DOCTYPE html>
<html>
<head>
    <title>Formulir Pendaftaran Siswa Baru | SMA Negeri 29 Jakarta</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            background-color: #fffbe7;
            color: #333;
        }
    </style>
</head>

<body>
    <header>
        <h3 class="text-center mt-4">Formulir Pendaftaran Siswa Baru</h3>
    </header>

    <div class="container my-4">
        <form action="proses-pendaftaran.php" method="POST">
            <fieldset>
                <div class="form-group row">
                    <label for="nama" class="col-sm-2 col-form-label">Nama:</label>
                    <div class="col-sm-10">
                        <input type="text" name="nama" class="form-control" placeholder="Nama lengkap">
                    </div>
                </div>
                <div class="form-group row">
                    <label for="alamat" class="col-sm-2 col-form-label">Alamat:</label>
                    <div class="col-sm-10">
                        <textarea name="alamat" class="form-control"></textarea>
                    </div>
                </div>
                <div class="form-group row">
                    <label for="jenis_kelamin" class="col-sm-2 col-form-label">Jenis Kelamin:</label>
                    <div class="col-sm-10">
                        <div class="form-check form-check-inline">
                            <input type="radio" name="jenis_kelamin" value="laki-laki" class="form-check-input">
                            <label class="form-check-label">Laki-laki</label>
                        </div>
                        <div class="form-check form-check-inline">
                            <input type="radio" name="jenis_kelamin" value="perempuan" class="form-check-input">
                            <label class="form-check-label">Perempuan</label>
                        </div>
                    </div>
                </div>
                <div class="form-group row">
                    <label for="agama" class="col-sm-2 col-form-label">Agama:</label>
                    <div class="col-sm-10">
                        <select name="agama" class="form-control">
                            <option>Islam</option>
                            <option>Kristen</option>
                            <option>Budha</option>
                        </select>
                    </div>
                </div>
                <div class="form-group row">
                    <label for="sekolah_asal" class="col-sm-2 col-form-label">Sekolah Asal:</label>
                    <div class="col-sm-10">
                        <input type="text" name="sekolah_asal" class="form-control" placeholder="Nama sekolah">
                    </div>
                </div>
                <div class="form-group text-center">
                    <button type="submit" class="btn btn-primary">Daftar</button>
                </div>
            </fieldset>
        </form>
    </div>

    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
