<!DOCTYPE html>
<html>
<head>
    <title>Pesan Hapus Siswa</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            background-color: #f8f9fa;
            padding: 20px;
        }

        .alert-container {
            max-width: 500px;
            margin: 0 auto;
        }

        .alert {
            margin-bottom: 10px;
        }

        .btn-container {
            text-align: center;
        }
    </style>
</head>
<body>
    <div class="alert-container">
        <?php
        include("config.php");

        // Memeriksa apakah ID siswa telah diberikan melalui parameter URL
        if (isset($_GET['id'])) {
            $id = $_GET['id'];

            // Query untuk menghapus data siswa berdasarkan ID
            $sql = "DELETE FROM calon_siswa WHERE id = $id";
            $query = mysqli_query($db, $sql);

            // Memeriksa apakah query berhasil dijalankan
            if ($query) {
                echo '<div class="alert alert-success" role="alert">
                          Data siswa berhasil dihapus.
                      </div>';
                echo '<div class="btn-container">
                          <a href="list-siswa.php" class="btn btn-primary">Kembali ke Daftar Siswa</a>
                      </div>';
            } else {
                echo '<div class="alert alert-danger" role="alert">
                          Terjadi kesalahan dalam menghapus data siswa.
                      </div>';
            }
        } else {
            echo '<div class="alert alert-warning" role="alert">
                      ID siswa tidak diberikan.
                  </div>';
            exit;
        }
        ?>
    </div>
</body>
</html>
