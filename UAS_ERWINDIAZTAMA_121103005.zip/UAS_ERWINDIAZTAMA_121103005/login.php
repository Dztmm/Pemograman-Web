<?php
// Cek apakah ada pengiriman data melalui metode POST
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
  // Masukkan username dan password yang valid di sini
  $valid_username = 'username';
  $valid_password = 'password';

  // Dapatkan data yang dikirimkan melalui formulir login
  $username = $_POST['username'];
  $password = $_POST['password'];

  // Periksa apakah username dan password sesuai dengan yang valid
  if ($username == $valid_username && $password == $valid_password) {
    // Jika sesuai, redirect ke halaman yang diinginkan
    header('Location: welcome.php');
    exit();
  } else {
    // Jika tidak sesuai, tampilkan pesan error
    $error = 'Username atau password salah';
  }
}
?>

<!DOCTYPE html>
<html>
<head>
  <title>Form Login</title>
</head>
<body>
  <h1>Form Login</h1>
  <?php if (isset($error)) { ?>
    <p style="color: red;"><?php echo $error; ?></p>
  <?php } ?>
  <form method="POST" action="">
    <label for="username">Username:</label><br>
    <input type="text" id="username" name="username" required><br><br>
    <label for="password">Password:</label><br>
    <input type="password" id="password" name="password" required><br><br>
    <input type="submit" value="Login">
  </form>
</body>
</html>
