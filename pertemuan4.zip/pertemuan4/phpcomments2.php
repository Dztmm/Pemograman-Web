<!DOCTYPE html>
<html>
<body>

<?php
/*
This is a multiples-lines comment block
that spans over multiple 
lines*/
?>

</body>
</html>