<!DOCTYPE html>
<html>
<body>

<?php
$txt1 = "Pemograman PHP";
$txt2 = "Lab Komputer";
$x = 5;
$y = 4;

echo "<h2>" . $txt1 . "</h2>";
echo "Belajar PHP di " . $txt2 . "<br>";
echo $x + $y;
?>

</body>
</html>